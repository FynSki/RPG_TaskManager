/**
 * Type definitions for TaskQuest application
 */

export type Project = {
    id: string;
    name: string;
    color: string;
    description: string;
};

export type SubTask = {
    id: string;
    name: string;
    completed: boolean;
};

export type TaskComment = {
    id: string;
    text: string;
    createdAt: string;
};

export type Task = {
    id: string;
    projectId: string | null;
    name: string;
    description: string;
    completed: boolean;
    xpReward: number;
    /** Gold przyznawany za ukończenie — wyliczany automatycznie z priority */
    goldReward: number;
    priority: "common" | "rare" | "epic" | "legendary" | "unique";
    dueDate: string;
    subtasks: SubTask[];
    createdAt: string;
    completedAt?: string;
    comments?: TaskComment[];
    isRecurring?: boolean;
    recurringType?: "daily" | "weekly" | "monthly";
    recurringDay?: number;
    recurringEndDate?: string;
    statType?: "strength" | "endurance" | "intelligence" | "agility" | "charisma" | null;
    classId?: string | null;
    skillId?: string | null;
    isFlexible?: boolean;
};

export type Character = {
    name: string;
    level: number;
    xp: number;
    totalXp: number;
    avatar: string;
    /** Aktualne gold postaci */
    gold: number;
    /** Łączne gold zdobyte w historii (do statystyk) */
    totalGold: number;
    strength: number;
    strengthProgress: number;
    endurance: number;
    enduranceProgress: number;
    intelligence: number;
    intelligenceProgress: number;
    agility: number;
    agilityProgress: number;
    charisma: number;
    charismaProgress: number;
    unspentPoints: number;
};

export type RecurringTaskCompletion = {
    taskId: string;
    date: string;
    completed: boolean;
};

export type TaskClass = {
    id: string;
    name: string;
    statType: "strength" | "endurance" | "intelligence" | "agility" | "charisma";
    color?: string;
};

export type Skill = {
    id: string;
    name: string;
    level: number;
    progress: number;
    color?: string;
};

export type ViewType =
    | "character"
    | "activeTasks"
    | "daily"
    | "weekly"
    | "monthly"
    | "all"
    | "projects"
    | "settings";

export type StatType = "strength" | "endurance" | "intelligence" | "agility" | "charisma";